package validator

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/gin-gonic/gin/binding"
	"gopkg.in/go-playground/validator.v9"
)

type CheckSystemUpdateRequest struct {
	ClientVersion string `json:"client_version" form:"client_version" validate:"required" comment:"客户端版本"`
}

func ValidateCheckSystemUpdateRequest(c *gin.Context) (*CheckSystemUpdateRequest, error) {
	var request CheckSystemUpdateRequest
	if err := c.ShouldBindWith(&request, binding.JSON); err != nil {
		// 参数验证失败
		errs, ok := err.(validator.ValidationErrors)
		if !ok {
			return nil, fmt.Errorf(err.Error())
		}
		var sliceErrs []string
		for _, e := range errs {
			//e.Field()
			sliceErrs = append(sliceErrs, e.Translate(Trans))
		}
		return nil, fmt.Errorf(sliceErrs[0])
	}
	return &request, nil
}
