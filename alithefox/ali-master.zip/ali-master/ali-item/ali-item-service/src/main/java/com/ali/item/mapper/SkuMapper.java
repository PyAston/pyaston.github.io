package com.ali.item.mapper;

import com.ali.item.pojo.Sku;
import tk.mybatis.mapper.common.Mapper;

/**
 * @Author:wangsusheng
 * @Date: 2020/1/19 16:17
 */
public interface SkuMapper extends Mapper<Sku> {
}
