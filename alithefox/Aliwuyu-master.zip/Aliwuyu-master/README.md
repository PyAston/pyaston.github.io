Aliwuyu（阿狸物语）
=======

## Introduction

* 一款Windows App
* 展示包括“阿狸的999封情书”、“阿狸的呓语”、“阿狸故事集”等阿狸特色作品
* 获得“博彦之星”设计开发大赛三等奖

## Update

1. 增加“阿狸小小笑话”版块，23个有关阿狸的笑话让你笑口常开。
2. 阿狸的999封情书更新至第150封。
3. 全新改版功能面板。
4. 增加了随机背景壁纸切换功能。
5. 增加了自定义纯色主题功能。
6. 播放的中文歌曲增加到5首，增强音乐阅读体验效果。
7. 修复部分bug。

## Link

* [阿狸物语](http://apps.microsoft.com/windows/zh-cn/app/c5882c35-fe4a-41b2-9099-2b2d83aeba8e)

## Contributor

* [Karezi](http://karez1.com/)
